import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:vuka_safety_platform/app/vuka_app.dart';
void main(){testWidgets('VUKA app boots into splash route', (tester) async {await tester.pumpWidget(const ProviderScope(child:VukaApp()));await tester.pumpAndSettle();expect(find.text('VUKA'),findsOneWidget);});}
