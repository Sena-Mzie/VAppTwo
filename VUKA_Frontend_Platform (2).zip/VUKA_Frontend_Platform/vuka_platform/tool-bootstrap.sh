#!/usr/bin/env sh
set -eu
# Generate native runner folders for the installed Flutter SDK version.
flutter create . --platforms=android,ios,web
flutter pub get
