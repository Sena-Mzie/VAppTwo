# VUKA Safety Intelligence Platform — Flutter Frontend

A single responsive Flutter codebase targeting **Android, iOS, and Web**. The mobile experience supports passenger and driver journeys; the web experience includes an administrator/moderator operations console and a read-only trusted-contact shared-trip route. The product is a safety intelligence platform, **not** a ride-hailing or transport marketplace.

## Included frontend modules

- Authentication journey: splash, welcome, registration, login, OTP and PIN screens; biometric service abstraction.
- Passenger: dashboard, create safety trip, trip safety profile, driver/vehicle verification, live monitoring, check-in, SOS, trusted contacts, incident report/map and profile.
- Driver: dashboard, incoming trip safety review, document upload selection, QR display state and QR scanner.
- Web operations: responsive administrator overview, moderation workflow, user/driver management and audit log.
- Trusted contact: read-only shared-trip route with expiry and server-confirmed status fields.
- Shared: centralized theme tokens, string catalogue, risk/incident models, sealed API result types, Dio client, secure token store, repository interfaces/implementations, analytics hook, location, push, WebSocket and offline-cache services.

## Run

Install the current Flutter stable SDK, Android Studio (for Android), Xcode (for iOS/macOS build hosts) and a modern browser.

```bash
cp .env.example .env
./tool-bootstrap.sh
flutter pub get
flutter run -d chrome       # Web
flutter run                 # Connected mobile device/emulator
flutter analyze
flutter test
```

The source bundle includes `tool-bootstrap.sh` to generate the Android, iOS and Web runner folders using your installed Flutter SDK. This environment does not contain the Flutter/Dart SDK; run `flutter analyze` and `flutter test` on a configured Flutter workstation before treating it as a verified build.

## Platform configuration required

### API

Set `API_BASE_URL` and `WS_BASE_URL` in `.env`. The frontend expects versioned endpoints including:

- `POST /auth/otp`, `POST /auth/otp/verify`, `POST /auth/logout`
- `POST /trips/safety-assessment`, `GET /trips/{id}`, `POST /trips/{id}/monitoring/start`, `POST /trips/{id}/sos`
- `POST /incidents`, `GET /incidents`, `POST /admin/incidents/{id}/moderation`
- `GET /trusted-contacts`, `POST /trusted-contacts`, `DELETE /trusted-contacts/{id}`
- `GET /admin/overview`, `GET /admin/audit`, `PATCH /admin/users/{id}`

The backend must enforce authorization, server-side risk scoring, idempotency, rate limits, report deduplication, confidence rules, audit logging, expiring share tokens and emergency escalation. The client must not calculate or invent authoritative risk scores.

### Google Maps

- Android: add the Maps API key to `android/app/src/main/AndroidManifest.xml` under the `com.google.android.geo.API_KEY` metadata entry.
- iOS: configure the Maps SDK key in the iOS app startup configuration.
- Web: configure the Google Maps JavaScript API key in `web/index.html`.
- Build with `--dart-define=VUKA_MAPS_CONFIGURED=true` after all platform keys and billing/restrictions are configured.

Until then, the map widget shows a deliberate configuration state instead of pretending live maps are available.

### Firebase / push

Create Firebase projects for each platform, add the platform configuration files (`google-services.json`, `GoogleService-Info.plist`, web Firebase options), initialise Firebase before using `PushNotificationService`, and configure APNs/web push credentials. Never commit production credentials.

### Android/iOS permissions

Configure location (foreground and, only where justified, background), camera, photo-library and biometric permissions in native platform manifests/plists. Explain consent before requesting sensitive permissions. Background monitoring requires OS-specific implementation and testing.

## Safety and privacy boundaries

- Sample labels and values in the visual screens are illustrative, not live threat intelligence.
- No emergency alert is sent by this source package until a real, authenticated SOS backend and response partner are configured and tested end-to-end.
- QR scan capture is not verification: the token must be signed, time-limited and checked by the server. Driver QR generation must use a backend-issued rotating credential.
- Risk values must be supplied by the risk service. When evidence is missing or stale, return and display `Insufficient data` rather than infer a safe/unsafe rating.
- Community reports must describe locations and events only, never identify individuals. Confidence levels and the five moderation stages are backend-authoritative.
- The shared-trip route must use a random, unguessable token (minimum 128 bits per the SRS), expire server-side and be revocable.
- JWTs, refresh tokens and PIN material must never be stored in SharedPreferences. Use platform secure storage and avoid logging secrets or precise personal location.

## Architecture

Feature-first Clean Architecture is represented under `lib/features/<feature>/{presentation,domain,data}`. API traffic belongs in repository implementations and returns the sealed `ApiResult<T>` type. Riverpod owns dependency injection; GoRouter owns route definitions. Theme tokens and the initial English string catalogue are centralised. Add generated ARB resources with Flutter gen-l10n when translations are introduced.

## Important implementation boundary

This is a substantial frontend starter with navigable feature screens, form validation, responsive layouts, service abstractions and API repository contracts. It is **not yet a production-connected safety platform**: no VUKA backend URL/schema, Firebase project, Google Maps keys, emergency response partner, identity provider or approved risk model was supplied. The UI intentionally does not claim those external integrations are live. Production release requires integration, native platform setup, full test coverage, security review, POPIA assessment, accessibility testing and field validation against the approved SRS.
