# VUKA frontend requirements coverage

| SRS module | Frontend route(s) | Current source coverage | External dependency / acceptance work |
|---|---|---|---|
| Account and onboarding (FR-ACC) | `/welcome`, `/register`, `/login`, `/otp`, `/create-pin`, `/profile` | Screens, form validation, secure-token abstraction, biometric service | OTP/PIN lifecycle, refresh-token rotation, role authorization, account recovery and POPIA consent API |
| Trip Safety Profile (FR-TSP) | `/create-trip`, `/trip-safety`, `/driver-incoming` | Trip input, risk summary presentation, risk colour tokens, insufficient-data wording | Places autocomplete, authoritative route/risk response, data freshness and safer-route service |
| Passenger verification (FR-VER) | `/verify-driver`, `/qr-scan`, `/driver-qr` | QR scanner, server QR verification repository contract, server-issued QR display | Signed QR issuance/verification, expiry enforcement, identity/vehicle data source and mismatch escalation |
| Trip sharing (FR-SHR) | `/trusted-contacts`, `/add-contact`, `/shared-trip` | Contact invitation and read-only share views | Consent, 128-bit+ unguessable expiring tokens, revocation, link delivery and server authorization |
| Journey monitoring (FR-MON) | `/active-trip`, `/safety-checkin` | Map integration point, route status presentation and check-in UI | Background location, route matching/deviation logic, realtime event stream, check-in timer and false-positive tuning |
| Emergency escalation (FR-ESC) | `/sos` | Press-and-hold action, active-trip lookup, location permission and backend SOS request contract | Emergency partner integration, acknowledgement states, contact notifications, on-call runbooks and end-to-end drills |
| Community reporting (FR-COM) | `/report-incident`, `/incident-map` | Report form, map surface and confidence/stage labels | Photo upload, GPS/map pin, deduplication, five-stage verification/scoring, moderation and report abuse controls |
| Risk assessment (FR-RSK) | `/trip-safety`, `/incident-map` | Risk model presentation and insufficient-data handling | Approved server-side scoring model, fairness review, configurable thresholds, decay and source freshness |
| Safety Intelligence API (FR-INT) | Repository/service layer | Dio client and typed repository contracts | Final API schema, partner authentication, rate limits, API versioning and partner SDK contract |
| Administration (FR-ADM) | `/admin`, `/admin/moderation`, `/admin/users`, `/admin/audit` | Responsive web operations views and repository interfaces | RBAC, moderation actions, audit immutability, exports, search, pagination and operational metrics |
| Notifications (FR-NOT) | `/notifications` | Firebase Messaging service abstraction and notification screen | Firebase project, APNs/web push configuration, notification templates, delivery receipts and deep links |
| Accessibility / usability | All screens | Material controls, scalable layouts, central theme, large tap-target button styles | WCAG 2.1 AA audit, screen-reader labels, contrast tests, user testing and NFR-UX-03 emergency-button test |

This is a frontend source baseline, not a signed acceptance report. Requirements that depend on a backend, external provider, legal decision, risk model or emergency partner remain unverified until the integrations and tests are complete.
