# Proposed VUKA API contract map

All endpoints are illustrative integration contracts derived from the frontend flows. Confirm request/response schemas, status codes, authorization scopes and idempotency semantics with the backend team before implementation.

## Authentication
- `POST /auth/otp` — `{ phone, role }`; returns challenge metadata.
- `POST /auth/otp/verify` — `{ phone, otp }`; returns user and token metadata.
- `POST /auth/logout` — revokes current refresh/session token.

## Trips and risk
- `POST /trips/safety-assessment` — `{ pickup, destination, departureAt?, mode?, role }`; returns pickup/route/destination assessments, overall rating, reasons, confidence/freshness, expected route and optional safer route.
- `GET /trips/active` — returns the current authenticated user's active trip or an explicit no-active-trip response.
- `GET /trips/{id}` — returns trip status, participants, route and current monitoring state.
- `POST /trips/{id}/monitoring/start` — starts consented monitoring and returns session metadata.
- `POST /trips/{id}/sos` — `{ latitude, longitude, eventId }`; returns explicit accepted/rejected/queued status and partner acknowledgement state. Use idempotency keys.

## Verification
- `POST /verification/driver/qr` — returns a short-lived signed credential and `expiresAt`; rotate within 60 seconds.
- `POST /verification/qr/verify` — `{ token }`; returns verified identity/vehicle match result without exposing unnecessary personal data.

## Trusted contacts
- `GET /trusted-contacts`, `POST /trusted-contacts`, `DELETE /trusted-contacts/{id}`.
- `GET /shared-trips/{unguessableToken}` — read-only, scope-limited and expiring; never enumerate trip IDs.

## Community reports and moderation
- `POST /incidents` — category, location, event time, optional description/photo reference and idempotency key.
- `GET /incidents?page=...` — paginated, privacy-filtered incident data with confidence and freshness.
- `POST /admin/incidents/{id}/moderation` — decision and reason; role-protected and audit logged.

## Administration
- `GET /admin/overview`, `GET /admin/audit?page=...`, `PATCH /admin/users/{id}`.

## Required response conventions
- Use a consistent envelope and correlation ID.
- Return machine-readable error codes and human-readable safe messages.
- Return `Insufficient data` for missing/stale/unreliable risk evidence; never infer a safe score client-side.
- Include confidence, source provenance and freshness with each incident signal.
- Use pagination, rate limiting, idempotency for mutation endpoints and server-side authorization on every protected resource.
