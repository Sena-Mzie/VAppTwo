// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Zulu (`zu`).
class AppLocalizationsZu extends AppLocalizations {
  AppLocalizationsZu([String locale = 'zu']) : super(locale);

  @override
  String get appName => 'VUKA';

  @override
  String get tagline => 'Bona ubungozi. Yazi uhambo. Fika ekhaya.';

  @override
  String get sos => 'SOS';

  @override
  String get tripSafetyProfile => 'Iphrofayela yokuphepha kohambo';

  @override
  String get insufficientData => 'Idatha ayanele';

  @override
  String get reportIncident => 'Bika isigameko';
}
