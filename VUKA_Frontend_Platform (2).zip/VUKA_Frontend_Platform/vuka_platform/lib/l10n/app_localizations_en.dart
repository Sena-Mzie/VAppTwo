// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appName => 'VUKA';

  @override
  String get tagline => 'See the risk. Know the journey. Get home.';

  @override
  String get sos => 'SOS';

  @override
  String get tripSafetyProfile => 'Trip Safety Profile';

  @override
  String get insufficientData => 'Insufficient data';

  @override
  String get reportIncident => 'Report an incident';
}
