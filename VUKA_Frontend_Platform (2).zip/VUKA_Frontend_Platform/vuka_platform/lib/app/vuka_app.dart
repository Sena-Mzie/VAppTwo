import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme/app_theme.dart';
import 'app_router.dart';
class VukaApp extends ConsumerWidget {
  const VukaApp({super.key});
  @override Widget build(BuildContext context, WidgetRef ref) => MaterialApp.router(title:'VUKA Safety Intelligence', debugShowCheckedModeBanner:false, theme:VukaTheme.light(), darkTheme:VukaTheme.dark(), themeMode:ThemeMode.system, routerConfig:ref.watch(appRouterProvider), supportedLocales: const [Locale('en'), Locale('zu'), Locale('af')]);
}
