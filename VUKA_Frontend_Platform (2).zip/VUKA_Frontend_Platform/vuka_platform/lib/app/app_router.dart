import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../features/auth/presentation/screens/splash_screen.dart';
import '../features/auth/presentation/screens/welcome_screen.dart';
import '../features/auth/presentation/screens/login_screen.dart';
import '../features/auth/presentation/screens/register_screen.dart';
import '../features/auth/presentation/screens/otp_verification_screen.dart';
import '../features/auth/presentation/screens/create_pin_screen.dart';
import '../features/dashboard/presentation/screens/home_dashboard_screen.dart';
import '../features/dashboard/presentation/screens/driver_dashboard_screen.dart';
import '../features/dashboard/presentation/screens/driver_incoming_screen.dart';
import '../features/trips/presentation/screens/create_trip_screen.dart';
import '../features/trips/presentation/screens/trip_safety_profile_screen.dart';
import '../features/verification/presentation/screens/driver_verification_screen.dart';
import '../features/verification/presentation/screens/driver_verification_upload_screen.dart';
import '../features/verification/presentation/screens/driver_qr_screen.dart';
import '../features/verification/presentation/screens/qr_scan_screen.dart';
import '../features/monitoring/presentation/screens/active_trip_screen.dart';
import '../features/sos/presentation/screens/sos_screen.dart';
import '../features/sos/presentation/screens/safety_checkin_screen.dart';
import '../features/contacts/presentation/screens/trusted_contacts_screen.dart';
import '../features/contacts/presentation/screens/add_contact_screen.dart';
import '../features/reports/presentation/screens/report_incident_screen.dart';
import '../features/reports/presentation/screens/incident_map_screen.dart';
import '../features/profile/presentation/screens/profile_screen.dart';
import '../features/notifications/presentation/screens/notifications_screen.dart';
import '../features/admin/presentation/screens/admin_dashboard_screen.dart';
import '../features/admin/presentation/screens/moderation_screen.dart';
import '../features/admin/presentation/screens/admin_users_screen.dart';
import '../features/admin/presentation/screens/audit_log_screen.dart';
import '../features/shared_trip/presentation/screens/shared_trip_screen.dart';
final appRouterProvider = Provider<GoRouter>((ref) => GoRouter(initialLocation: '/splash', routes: [
  GoRoute(path:'/splash',builder:(c,s)=>const SplashScreen()), GoRoute(path:'/welcome',builder:(c,s)=>const WelcomeScreen()),
  GoRoute(path:'/login',builder:(c,s)=>const LoginScreen()), GoRoute(path:'/register',builder:(c,s)=>const RegisterScreen()),
  GoRoute(path:'/otp',builder:(c,s)=>const OtpVerificationScreen()), GoRoute(path:'/create-pin',builder:(c,s)=>const CreatePinScreen()),
  GoRoute(path:'/home',builder:(c,s)=>const HomeDashboardScreen()), GoRoute(path:'/driver-dashboard',builder:(c,s)=>const DriverDashboardScreen()), GoRoute(path:'/driver-incoming',builder:(c,s)=>const DriverIncomingScreen()),
  GoRoute(path:'/create-trip',builder:(c,s)=>const CreateTripScreen()), GoRoute(path:'/trip-safety',builder:(c,s)=>const TripSafetyProfileScreen()),
  GoRoute(path:'/verify-driver',builder:(c,s)=>const DriverVerificationScreen()), GoRoute(path:'/driver-verification-upload',builder:(c,s)=>const DriverVerificationUploadScreen()), GoRoute(path:'/driver-qr',builder:(c,s)=>const DriverQrScreen()), GoRoute(path:'/qr-scan',builder:(c,s)=>const QrScanScreen()),
  GoRoute(path:'/active-trip',builder:(c,s)=>const ActiveTripScreen()), GoRoute(path:'/sos',builder:(c,s)=>const SosScreen()), GoRoute(path:'/safety-checkin',builder:(c,s)=>const SafetyCheckinScreen()),
  GoRoute(path:'/trusted-contacts',builder:(c,s)=>const TrustedContactsScreen()), GoRoute(path:'/add-contact',builder:(c,s)=>const AddContactScreen()),
  GoRoute(path:'/report-incident',builder:(c,s)=>const ReportIncidentScreen()), GoRoute(path:'/incident-map',builder:(c,s)=>const IncidentMapScreen()), GoRoute(path:'/profile',builder:(c,s)=>const ProfileScreen()),
  GoRoute(path:'/admin',builder:(c,s)=>const AdminDashboardScreen()), GoRoute(path:'/admin/moderation',builder:(c,s)=>const ModerationScreen()), GoRoute(path:'/admin/users',builder:(c,s)=>const AdminUsersScreen()), GoRoute(path:'/admin/audit',builder:(c,s)=>const AuditLogScreen()),
  GoRoute(path:'/shared-trip',builder:(c,s)=>const SharedTripScreen()), GoRoute(path:'/notifications',builder:(c,s)=>const NotificationsScreen()),
]));
