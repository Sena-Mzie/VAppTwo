enum RiskLevel { low, moderate, elevated, high, insufficientData }
enum IncidentCategory { hijacking, robbery, smashAndGrab, suspiciousActivity, unsafeDropOff, roadBlocked, other }
enum IncidentStage { received, verified, compared, scored, alerted }
enum ConfidenceLevel { low, higher, high, verified }
class RiskAssessment {
  const RiskAssessment({required this.level, required this.summary, required this.updatedAt, this.score, this.reasons = const [], this.sourceFresh = true});
  final RiskLevel level; final String summary; final DateTime updatedAt; final int? score; final List<String> reasons; final bool sourceFresh;
  factory RiskAssessment.fromJson(Map<String, dynamic> j) => RiskAssessment(level: RiskLevel.values.firstWhere((e) => e.name == j['level'], orElse: () => RiskLevel.insufficientData), summary: j['summary'] as String? ?? '', updatedAt: DateTime.tryParse(j['updatedAt'] as String? ?? '') ?? DateTime.now(), score: j['score'] as int?, reasons: (j['reasons'] as List? ?? []).whereType<String>().toList(), sourceFresh: j['sourceFresh'] as bool? ?? false);
}
class IncidentReport {
  const IncidentReport({required this.id, required this.category, required this.description, required this.stage, required this.confidence, required this.createdAt, this.latitude, this.longitude});
  final String id, description; final IncidentCategory category; final IncidentStage stage; final ConfidenceLevel confidence; final DateTime createdAt; final double? latitude, longitude;
}
