enum UserRole { passenger, driver, administrator, moderator, trustedContact }
enum AccountStatus { active, pending, suspended }
class VukaUser {
  const VukaUser({required this.id, required this.fullName, required this.phone, required this.role, this.email, this.status = AccountStatus.active});
  final String id, fullName, phone; final String? email; final UserRole role; final AccountStatus status;
  factory VukaUser.fromJson(Map<String, dynamic> json) => VukaUser(id: json['id'] as String, fullName: json['fullName'] as String, phone: json['phone'] as String, email: json['email'] as String?, role: UserRole.values.firstWhere((e) => e.name == json['role'], orElse: () => UserRole.passenger), status: AccountStatus.values.firstWhere((e) => e.name == json['status'], orElse: () => AccountStatus.active));
  Map<String, dynamic> toJson() => {'id': id, 'fullName': fullName, 'phone': phone, 'email': email, 'role': role.name, 'status': status.name};
}
