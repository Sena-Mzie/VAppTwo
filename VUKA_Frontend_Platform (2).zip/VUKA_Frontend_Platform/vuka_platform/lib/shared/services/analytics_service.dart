import 'package:flutter/foundation.dart';
class AnalyticsService {
  const AnalyticsService();
  void track(String event, [Map<String, Object?> properties = const {}]) {
    // Replace this sink with the approved analytics provider after privacy review.
    if (kDebugMode) debugPrint('VUKA_ANALYTICS $event $properties');
  }
}
