import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/colors.dart';
import 'page_scaffold.dart';
import 'vuka_components.dart';
class ValidatedFormPage extends StatefulWidget {
  const ValidatedFormPage({super.key, required this.title, required this.description, required this.fields, required this.submitLabel, this.successMessage = 'Your information has been saved.', this.nextRoute});
  final String title, description, submitLabel, successMessage; final List<(String, TextInputType)> fields; final String? nextRoute;
  @override State<ValidatedFormPage> createState() => _ValidatedFormPageState();
}
class _ValidatedFormPageState extends State<ValidatedFormPage> {
  final _form = GlobalKey<FormState>(); late final List<TextEditingController> _controllers;
  @override void initState() { super.initState(); _controllers = List.generate(widget.fields.length, (_) => TextEditingController()); }
  @override void dispose() { for (final c in _controllers) { c.dispose(); } super.dispose(); }
  @override Widget build(BuildContext context) => VukaPageScaffold(title: widget.title, showSos: true, child: ListView(padding: const EdgeInsets.all(20), children: [Text(widget.description, style: const TextStyle(color: VukaColors.muted, height: 1.5)), const SizedBox(height: 18), Form(key: _form, child: Column(children: [for (var i = 0; i < widget.fields.length; i++) ...[Align(alignment: Alignment.centerLeft, child: Padding(padding: const EdgeInsets.only(bottom: 7, top: 12), child: Text(widget.fields[i].$1, style: const TextStyle(color: VukaColors.muted, fontWeight: FontWeight.w700)))), TextFormField(controller: _controllers[i], keyboardType: widget.fields[i].$2, validator: (v) { final value = v?.trim() ?? ''; if (value.isEmpty) return '${widget.fields[i].$1} is required'; if (widget.fields[i].$2 == TextInputType.emailAddress && !RegExp(r'^[^@]+@[^@]+\.[^@]+$').hasMatch(value)) return 'Enter a valid email address'; if (widget.fields[i].$2 == TextInputType.phone && value.replaceAll(RegExp(r'\D'), '').length < 9) return 'Enter a valid phone number'; return null; })], const SizedBox(height: 24), PrimaryAction(widget.submitLabel, icon: Icons.check, onPressed: _submit)]))]));
  void _submit() { if (!_form.currentState!.validate()) return; ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(widget.successMessage))); if (widget.nextRoute != null) context.push(widget.nextRoute!); }
}
