import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../../core/theme/colors.dart';

class SafetyGoogleMap extends StatelessWidget {
  const SafetyGoogleMap({super.key, this.height = 260});
  final double height;
  static const configured = bool.fromEnvironment('VUKA_MAPS_CONFIGURED', defaultValue: false);

  @override
  Widget build(BuildContext context) => SizedBox(
    height: height,
    child: ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: configured
          ? const GoogleMap(
              initialCameraPosition: CameraPosition(target: LatLng(-26.1076, 28.0567), zoom: 12),
              myLocationEnabled: false,
              zoomControlsEnabled: false,
              mapToolbarEnabled: false,
            )
          : Container(
              color: VukaColors.surface2,
              child: const Center(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.map_outlined, size: 38, color: VukaColors.amber),
                    SizedBox(height: 10),
                    Text('Map integration ready', style: TextStyle(fontWeight: FontWeight.w800)),
                    SizedBox(height: 5),
                    Text('Configure Google Maps keys for Android, iOS and Web to display live maps.', textAlign: TextAlign.center, style: TextStyle(color: VukaColors.muted, fontSize: 12)),
                  ]),
                ),
              ),
            ),
    ),
  );
}
