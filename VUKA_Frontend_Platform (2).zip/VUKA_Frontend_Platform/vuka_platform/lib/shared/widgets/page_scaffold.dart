import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/colors.dart';
//import 'vuka_components.dart';
class VukaPageScaffold extends StatelessWidget {
  const VukaPageScaffold({super.key, required this.title, required this.child, this.showSos = false, this.back = true});
  final String title; final Widget child; final bool showSos, back;
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(leading: back ? IconButton(tooltip: 'Back', onPressed: () => context.pop(), icon: const Icon(Icons.chevron_left)) : null, title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), actions: [if (showSos) IconButton(tooltip: 'SOS', onPressed: () => context.push('/sos'), icon: const Icon(Icons.sos, color: VukaColors.red))]), body: SafeArea(child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 900), child: child))));
}
class FeaturePage extends StatelessWidget {
  const FeaturePage({super.key, required this.title, required this.description, required this.sections, this.actions = const [], this.showSos = false});
  final String title, description; final List<Widget> sections; final List<Widget> actions; final bool showSos;
  @override Widget build(BuildContext context) => VukaPageScaffold(title: title, showSos: showSos, child: ListView(padding: const EdgeInsets.all(20), children: [Text(description, style: const TextStyle(color: VukaColors.muted, height: 1.5)), const SizedBox(height: 18), ...sections, if (actions.isNotEmpty) ...[const SizedBox(height: 12), ...actions.map((w) => Padding(padding: const EdgeInsets.only(bottom: 10), child: w))]]));
}
class InfoRow extends StatelessWidget { const InfoRow(this.label, this.value, {super.key, this.trailing}); final String label, value; final Widget? trailing; @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Row(children: [Expanded(child: Text(label, style: const TextStyle(color: VukaColors.muted))), Text(value, style: const TextStyle(fontWeight: FontWeight.w700)), if (trailing != null) ...[const SizedBox(width: 8), trailing!]])); }
