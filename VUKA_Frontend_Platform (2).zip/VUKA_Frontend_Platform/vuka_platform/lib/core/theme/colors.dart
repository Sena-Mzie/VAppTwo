import 'package:flutter/material.dart';
class VukaColors {
  VukaColors._();
  static const ink = Color(0xFF091321);
  static const surface = Color(0xFF112136);
  static const surface2 = Color(0xFF16283F);
  static const border = Color(0xFF263951);
  static const amber = Color(0xFFFFB30B);
  static const green = Color(0xFF42C59A);
  static const red = Color(0xFFFF686F);
  static const orange = Color(0xFFFF914D);
  static const muted = Color(0xFF8C9AAF);
  static const text = Color(0xFFE8EDF5);
  static const lightInk = Color(0xFFF3F6FA);
  static const lightSurface = Color(0xFFFFFFFF);
  static const lightText = Color(0xFF172438);
}
