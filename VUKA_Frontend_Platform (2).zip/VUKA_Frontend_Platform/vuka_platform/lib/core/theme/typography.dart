import 'package:flutter/material.dart';
import 'colors.dart';
class VukaTypography {
  VukaTypography._();
  static const display = TextStyle(fontSize: 30, height: 1.15, fontWeight: FontWeight.w900, letterSpacing: .3, color: VukaColors.text);
  static const heading = TextStyle(fontSize: 20, height: 1.25, fontWeight: FontWeight.w800, color: VukaColors.text);
  static const title = TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: VukaColors.text);
  static const body = TextStyle(fontSize: 14, height: 1.5, color: VukaColors.text);
  static const caption = TextStyle(fontSize: 12, height: 1.4, color: VukaColors.muted);
  static const eyebrow = TextStyle(fontSize: 10, letterSpacing: 1.3, fontWeight: FontWeight.w800, color: VukaColors.muted);
}
