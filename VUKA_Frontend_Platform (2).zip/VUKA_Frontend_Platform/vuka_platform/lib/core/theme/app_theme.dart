import 'package:flutter/material.dart';
import 'colors.dart';
class VukaTheme {
  static ThemeData dark() => ThemeData(
    useMaterial3: true, brightness: Brightness.dark, scaffoldBackgroundColor: VukaColors.ink,
    colorScheme: const ColorScheme.dark(primary: VukaColors.amber, surface: VukaColors.surface, error: VukaColors.red),
    appBarTheme: const AppBarTheme(backgroundColor: VukaColors.ink, foregroundColor: VukaColors.text, centerTitle: false, elevation: 0),
    cardTheme: CardThemeData(color: VukaColors.surface, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: VukaColors.border))),
    inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: VukaColors.surface2, hintStyle: const TextStyle(color: VukaColors.muted), contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15), border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide.none), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: const BorderSide(color: VukaColors.border)), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: const BorderSide(color: VukaColors.amber))),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(minimumSize: const Size(48, 52), backgroundColor: VukaColors.amber, foregroundColor: VukaColors.ink, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)), textStyle: const TextStyle(fontWeight: FontWeight.w800))),
    outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(minimumSize: const Size(48, 48), foregroundColor: VukaColors.text, side: const BorderSide(color: VukaColors.border), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)))),
  );
  static ThemeData light() => ThemeData(useMaterial3: true, brightness: Brightness.light, scaffoldBackgroundColor: VukaColors.lightInk, colorScheme: ColorScheme.fromSeed(seedColor: VukaColors.amber, brightness: Brightness.light));
}
