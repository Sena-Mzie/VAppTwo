sealed class ApiResult<T> {
  const ApiResult();
  R fold<R>({required R Function(T data) success, required R Function(String message, int? statusCode) failure}) => switch (this) {
    ApiSuccess<T>(:final data) => success(data),
    ApiFailure<T>(:final message, :final statusCode) => failure(message, statusCode),
  };
}
final class ApiSuccess<T> extends ApiResult<T> { const ApiSuccess(this.data); final T data; }
final class ApiFailure<T> extends ApiResult<T> { const ApiFailure(this.message, {this.statusCode}); final String message; final int? statusCode; }
