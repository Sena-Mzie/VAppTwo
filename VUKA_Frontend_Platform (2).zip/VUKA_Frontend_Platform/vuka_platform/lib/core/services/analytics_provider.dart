import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../shared/services/analytics_service.dart';

/// Single unified provider for AnalyticsService to prevent duplication
final analyticsServiceProvider = Provider<AnalyticsService>((ref) {
  return const AnalyticsService();
});
