import 'package:dio/dio.dart';
import '../errors/api_result.dart';
class SafetyRepository {
  SafetyRepository(this._dio); final Dio _dio;
  Future<ApiResult<Map<String,dynamic>>> getActiveTrip() async { try { final r = await _dio.get('/trips/active'); return ApiSuccess(Map<String,dynamic>.from(r.data as Map)); } on DioException catch(e) { return ApiFailure(e.message ?? 'Unable to find active trip', statusCode:e.response?.statusCode); } catch(e) { return ApiFailure(e.toString()); } }
  Future<ApiResult<Map<String,dynamic>>> createTrip({required String pickup, required String destination}) async => _post('/trips/safety-assessment', {'pickup':pickup,'destination':destination});
  Future<ApiResult<Map<String,dynamic>>> startMonitoring(String tripId) async => _post('/trips/$tripId/monitoring/start', const {});
  Future<ApiResult<Map<String,dynamic>>> submitIncident(Map<String,dynamic> payload) async => _post('/incidents', payload);
  Future<ApiResult<Map<String,dynamic>>> sendSos(String tripId, {required double latitude, required double longitude}) async => _post('/trips/$tripId/sos', {'latitude':latitude,'longitude':longitude});
  Future<ApiResult<Map<String,dynamic>>> _post(String path, Map<String,dynamic> body) async { try { final r = await _dio.post(path,data:body); return ApiSuccess(Map<String,dynamic>.from(r.data as Map)); } on DioException catch(e) { return ApiFailure(e.message ?? 'Network request failed',statusCode:e.response?.statusCode); } catch(e) { return ApiFailure(e.toString()); } }
}
