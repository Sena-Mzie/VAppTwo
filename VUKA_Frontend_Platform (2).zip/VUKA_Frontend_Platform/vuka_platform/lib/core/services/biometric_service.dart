import 'package:local_auth/local_auth.dart';
class BiometricService {
  final LocalAuthentication _auth = LocalAuthentication();
  Future<bool> canAuthenticate() async => await _auth.canCheckBiometrics || await _auth.isDeviceSupported();
  Future<bool> authenticate() async { if (!await canAuthenticate()) return false; try { return await _auth.authenticate(localizedReason: 'Authenticate to access your VUKA safety account'); } catch (_) { return false; } }
}
