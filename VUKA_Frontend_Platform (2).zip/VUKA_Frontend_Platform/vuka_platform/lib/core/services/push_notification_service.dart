import 'package:firebase_messaging/firebase_messaging.dart';

class PushNotificationService {
  Future<String?> initialise() async { 
    try { 
      final settings = await FirebaseMessaging.instance.requestPermission(
        alert: true, 
        badge: true, 
        sound: true,
      ); 
      
      if (settings.authorizationStatus == AuthorizationStatus.denied) {
        return null; 
      }
      
      // Add 'await' here so exceptions are properly caught by the try-catch block
      return await FirebaseMessaging.instance.getToken(); 
    } catch (_) { 
      return null; 
    } 
  }

  Stream<RemoteMessage> get foregroundMessages => FirebaseMessaging.onMessage;
}
