import 'package:hive_flutter/hive_flutter.dart';
class OfflineCacheService {
  static const _boxName = 'vuka_cache';
  Future<void> initialise() async { await Hive.initFlutter(); if (!Hive.isBoxOpen(_boxName)) await Hive.openBox<dynamic>(_boxName); }
  Future<void> put(String key, Object? value) async { final box = await Hive.openBox<dynamic>(_boxName); await box.put(key, value); }
  Future<T?> get<T>(String key) async { final box = await Hive.openBox<dynamic>(_boxName); return box.get(key) as T?; }
  Future<void> clear() async { final box = await Hive.openBox<dynamic>(_boxName); await box.clear(); }
}
