import 'package:geolocator/geolocator.dart';
class LocationService {
  Future<bool> requestPermission() async { if (!await Geolocator.isLocationServiceEnabled()) return false; var p = await Geolocator.checkPermission(); if (p == LocationPermission.denied) p = await Geolocator.requestPermission(); return p == LocationPermission.whileInUse || p == LocationPermission.always; }
  Future<Position?> currentPosition() async { if (!await requestPermission()) return null; return Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 15))); }
  Stream<Position> watchPosition() => Geolocator.getPositionStream(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 25));
}
