import 'dart:async';
import 'package:web_socket_channel/web_socket_channel.dart';
class RealtimeService {
  WebSocketChannel? _channel;
  Stream<dynamic> connect(Uri uri) { _channel?.sink.close(); _channel = WebSocketChannel.connect(uri); return _channel!.stream; }
  void send(Object message) => _channel?.sink.add(message);
  Future<void> dispose() async { await _channel?.sink.close(); _channel = null; }
}
