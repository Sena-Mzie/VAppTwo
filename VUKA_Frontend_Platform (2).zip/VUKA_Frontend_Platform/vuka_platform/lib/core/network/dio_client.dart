import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import '../storage/secure_token_store.dart';
final dioProvider = Provider<Dio>((ref) {
  final dio = Dio(BaseOptions(baseUrl: dotenv.env['API_BASE_URL'] ?? 'https://api.example.com/v1', connectTimeout: const Duration(seconds: 15), receiveTimeout: const Duration(seconds: 20), headers: {'Accept': 'application/json', 'Content-Type': 'application/json'}));
  dio.interceptors.add(InterceptorsWrapper(onRequest: (options, handler) async { final token = await ref.read(secureTokenStoreProvider).readAccessToken(); if (token != null) options.headers['Authorization'] = 'Bearer $token'; handler.next(options); }));
  return dio;
});
