import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
final secureTokenStoreProvider = Provider<SecureTokenStore>((ref) => SecureTokenStore());
class SecureTokenStore {
  static const _storage = FlutterSecureStorage();
  Future<void> saveAccessToken(String value) => _storage.write(key: 'vuka_access_token', value: value);
  Future<void> saveRefreshToken(String value) => _storage.write(key: 'vuka_refresh_token', value: value);
  Future<String?> readAccessToken() => _storage.read(key: 'vuka_access_token');
  Future<String?> readRefreshToken() => _storage.read(key: 'vuka_refresh_token');
  Future<void> clear() => _storage.deleteAll();
}
