import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/theme/colors.dart';
import '../../../../shared/widgets/vuka_components.dart';

class SafetyCheckinScreen extends StatefulWidget {
  const SafetyCheckinScreen({super.key});

  @override
  State<SafetyCheckinScreen> createState() => _SafetyCheckinScreenState();
}

class _SafetyCheckinScreenState extends State<SafetyCheckinScreen> {
  final _pin = TextEditingController();
  bool resolved = false;

  @override
  void dispose() {
    _pin.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Trip update'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Icon(Icons.route, color: VukaColors.amber, size: 42),
          const SizedBox(height: 12),
          const Text(
            'Is everything okay?',
            style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 8),
          const Text(
            'Your route changed. This can happen because of traffic or a detour. Please update your trip status.',
            style: TextStyle(color: VukaColors.muted, height: 1.5),
          ),
          const SizedBox(height: 22),
          TextField(
            controller: _pin,
            obscureText: true,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'Enter your safety PIN',
            ),
          ),
          const SizedBox(height: 18),
          PrimaryAction(
            'I’m OK',
            onPressed: () => _respond(context, 'ok'),
          ),
          const SizedBox(height: 10),
          SecondaryAction(
            'Expected detour',
            onPressed: () => _respond(context, 'detour'),
          ),
          const SizedBox(height: 10),
          SecondaryAction(
            'I need help',
            danger: true,
            onPressed: () => context.push('/sos'),
          ),
          if (resolved)
            const Padding(
              padding: EdgeInsets.only(top: 14),
              child: Text(
                'Your response has been recorded locally. Server confirmation is required.',
                style: TextStyle(color: VukaColors.green),
              ),
            ),
        ],
      ),
    );
  }

  void _respond(BuildContext context, String response) {
    if (_pin.text.length < 4) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter your safety PIN to continue.')),
      );
      return;
    }

    // Dismiss keyboard safely
    FocusScope.of(context).unfocus();

    setState(() {
      resolved = true;
    });

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Response selected: $response. Connect the check-in endpoint to confirm with VUKA.',
        ),
      ),
    );
  }
}
