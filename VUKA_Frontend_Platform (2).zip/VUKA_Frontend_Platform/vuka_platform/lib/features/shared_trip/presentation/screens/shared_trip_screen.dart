import 'package:flutter/material.dart';
//import 'package:go_router/go_router.dart';
import '../../../../shared/widgets/page_scaffold.dart';
import '../../../../shared/widgets/vuka_components.dart';
class SharedTripScreen extends StatelessWidget { const SharedTripScreen({super.key});
 @override
 Widget build(BuildContext context) => FeaturePage(
  title: 'Shared trip view',
  description: 'A read-only, expiring trip view for an invited trusted contact. The link must be unguessable, time-limited and revocable.',
  showSos: true, sections: const[VukaCard(child:
  Column(crossAxisAlignment: CrossAxisAlignment.start,
  children: [Eyebrow('Safety overview'),
  SizedBox(height: 10),
  InfoRow('Journey status', 'Shared by passenger', trailing: SizedBox.shrink()),
  InfoRow('Last location update', 'Timestamp from service', trailing: SizedBox.shrink()),
  InfoRow('Safety status', 'Server-confirmed status', trailing: SizedBox.shrink()),
  InfoRow('Link expiry', 'Shown by backend', trailing: SizedBox.shrink())]))],
  actions: [SecondaryAction('Contact trip owner', onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Contact method is provided by your VUKA service.'))))]);
}
