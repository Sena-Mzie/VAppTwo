import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../shared/widgets/page_scaffold.dart';
import '../../../../shared/widgets/vuka_components.dart';

class AuditLogScreen extends StatelessWidget {
  const AuditLogScreen({super.key});

  @override
  Widget build(BuildContext context) => FeaturePage(
        title: 'Audit log',
        description:
            'View immutable records of privileged actions, safety-rule changes, moderation decisions and access events.',
        showSos: true,
        sections: const [
          VukaCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Eyebrow('Safety overview'),
                SizedBox(height: 10),
                InfoRow(
                  'Filters',
                  'Actor · action · date · entity',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Retention',
                  'Per approved retention policy',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Export',
                  'Permission controlled',
                  trailing: SizedBox.shrink(),
                ),
              ],
            ),
          ),
        ],
        actions: [
          PrimaryAction(
            'Back to operations',
            onPressed: () => context.push('/admin'),
          ),
        ],
      );
}