import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/theme/colors.dart';
import '../../../../shared/widgets/page_scaffold.dart';
import '../../../../shared/widgets/vuka_components.dart';

class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) => VukaPageScaffold(
        title: 'Safety operations',
        back: false,
        child: LayoutBuilder(
          builder: (context, c) {
            final wide = c.maxWidth >= 760;
            final tiles = [
              (
                'Open reports',
                'Moderation queue',
                Icons.fact_check_outlined,
                '/admin/moderation'
              ),
              (
                'User management',
                'Passengers and drivers',
                Icons.people_alt_outlined,
                '/admin/users'
              ),
              (
                'Incident intelligence',
                'Map and heatmap',
                Icons.map_outlined,
                '/incident-map'
              ),
              (
                'Audit log',
                'Privileged activity',
                Icons.receipt_long_outlined,
                '/admin/audit'
              ),
            ];

            return ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const Text(
                  'VUKA operations',
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Authorised administrator workspace · live metrics require the connected API.',
                  style: TextStyle(color: VukaColors.muted),
                ),
                const SizedBox(height: 18),
                GridView.count(
                  crossAxisCount: wide ? 4 : 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 1.35,
                  children: [
                    _metric('Open queue', '—'),
                    _metric('SLA target', '5 days'),
                    _metric('Data freshness', '—'),
                    _metric('Service health', '—'),
                  ],
                ),
                const SizedBox(height: 20),
                Text(
                  'Operations modules',
                  style: Theme.of(context)
                      .textTheme
                      .titleLarge
                      ?.copyWith(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 10),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: tiles.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: wide ? 2 : 1,
                    mainAxisExtent: 94,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                  ),
                  itemBuilder: (context, i) {
                    final t = tiles[i];
                    return InkWell(
                      onTap: () => context.push(t.$4),
                      borderRadius: BorderRadius.circular(16),
                      child: VukaCard(
                        child: Row(
                          children: [
                            Icon(
                              t.$3,
                              color: VukaColors.amber,
                              size: 28,
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    t.$1,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                  Text(
                                    t.$2,
                                    style: const TextStyle(
                                      color: VukaColors.muted,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const Icon(Icons.chevron_right),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ],
            );
          },
        ),
      );
}

Widget _metric(String label, String value) => VukaCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: VukaColors.muted,
              fontSize: 11,
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontSize: 23,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );