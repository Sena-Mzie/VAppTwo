import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../shared/widgets/page_scaffold.dart';
import '../../../../shared/widgets/vuka_components.dart';

class ModerationScreen extends StatelessWidget {
  const ModerationScreen({super.key});

  @override
  Widget build(BuildContext context) => FeaturePage(
        title: 'Incident moderation',
        description:
            'Review reports through Received, Verified, Compared, Scored and Alerted. Record every decision with moderator identity and reason.',
        showSos: true,
        sections: const [
          VukaCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Eyebrow('Safety overview'),
                SizedBox(height: 10),
                InfoRow(
                  'Received',
                  'New submissions',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Verified',
                  'Account, location and duplicate checks',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Compared',
                  'Independent reports within configured radius/time',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Scored',
                  'Confidence and age weighting',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Alerted',
                  'Only eligible confidence levels',
                  trailing: SizedBox.shrink(),
                ),
              ],
            ),
          ),
        ],
        actions: [
          PrimaryAction(
            'Open audit log',
            onPressed: () => context.push('/admin/audit'),
          ),
        ],
      );
}