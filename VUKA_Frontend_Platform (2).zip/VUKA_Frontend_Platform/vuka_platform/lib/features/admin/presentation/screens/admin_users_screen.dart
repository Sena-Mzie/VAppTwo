import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../shared/widgets/page_scaffold.dart';
import '../../../../shared/widgets/vuka_components.dart';

class AdminUsersScreen extends StatelessWidget {
  const AdminUsersScreen({super.key});

  @override
  Widget build(BuildContext context) => FeaturePage(
        title: 'User and driver management',
        description:
            'Manage account status and verification workflows with least-privilege access and an auditable change history.',
        showSos: true,
        sections: const [
          VukaCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Eyebrow('Safety overview'),
                SizedBox(height: 10),
                InfoRow(
                  'Passenger accounts',
                  'Search and status',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Driver accounts',
                  'Identity and vehicle verification',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Suspended accounts',
                  'Review and reinstate',
                  trailing: SizedBox.shrink(),
                ),
              ],
            ),
          ),
        ],
        actions: [
          PrimaryAction(
            'Open moderation queue',
            onPressed: () => context.push('/admin/moderation'),
          ),
        ],
      );
}