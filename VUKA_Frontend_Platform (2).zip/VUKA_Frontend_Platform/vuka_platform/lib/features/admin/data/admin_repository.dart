import 'package:dio/dio.dart';
import '../../../core/errors/api_result.dart';
abstract interface class AdminRepository { Future<ApiResult<Map<String,dynamic>>> overview(); Future<ApiResult<List<Map<String,dynamic>>>> audit({int page=1}); Future<ApiResult<Map<String,dynamic>>> updateAccount(String id,String status); }
class RemoteAdminRepository implements AdminRepository { RemoteAdminRepository(this._dio); final Dio _dio;
 @override Future<ApiResult<Map<String,dynamic>>> overview()=>_map(()=>_dio.get('/admin/overview'));
 @override Future<ApiResult<List<Map<String,dynamic>>>> audit({int page=1}) async {try{final r=await _dio.get('/admin/audit',queryParameters:{'page':page});return ApiSuccess((r.data['items'] as List? ?? []).map((e)=>Map<String,dynamic>.from(e as Map)).toList());}on DioException catch(e){return ApiFailure(e.message??'Audit service unavailable',statusCode:e.response?.statusCode);}catch(e){return ApiFailure(e.toString());}}
 @override Future<ApiResult<Map<String,dynamic>>> updateAccount(String id,String status)=>_map(()=>_dio.patch('/admin/users/$id',data:{'status':status}));
 Future<ApiResult<Map<String,dynamic>>> _map(Future<Response<dynamic>> Function() call) async {try{final r=await call();return ApiSuccess(Map<String,dynamic>.from(r.data as Map));}on DioException catch(e){return ApiFailure(e.message??'Admin service unavailable',statusCode:e.response?.statusCode);}catch(e){return ApiFailure(e.toString());}}
}
