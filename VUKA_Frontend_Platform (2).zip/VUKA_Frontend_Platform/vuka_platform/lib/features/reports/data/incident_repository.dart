import 'package:dio/dio.dart';
import '../../../core/errors/api_result.dart';
abstract interface class IncidentRepository { Future<ApiResult<Map<String,dynamic>>> submit(Map<String,dynamic> report); Future<ApiResult<List<Map<String,dynamic>>>> list({int page=1}); Future<ApiResult<Map<String,dynamic>>> moderate(String id,String decision,String reason); }
class RemoteIncidentRepository implements IncidentRepository { RemoteIncidentRepository(this._dio); final Dio _dio;
 @override Future<ApiResult<Map<String,dynamic>>> submit(Map<String,dynamic> report)=>_map(()=>_dio.post('/incidents',data:report));
 @override Future<ApiResult<List<Map<String,dynamic>>>> list({int page=1}) async {try{final r=await _dio.get('/incidents',queryParameters:{'page':page});final list=(r.data['items'] as List? ?? []).map((e)=>Map<String,dynamic>.from(e as Map)).toList();return ApiSuccess(list);}on DioException catch(e){return ApiFailure(e.message??'Unable to load incidents',statusCode:e.response?.statusCode);}catch(e){return ApiFailure(e.toString());}}
 @override Future<ApiResult<Map<String,dynamic>>> moderate(String id,String decision,String reason)=>_map(()=>_dio.post('/admin/incidents/$id/moderation',data:{'decision':decision,'reason':reason}));
 Future<ApiResult<Map<String,dynamic>>> _map(Future<Response<dynamic>> Function() call) async {try{final r=await call();return ApiSuccess(Map<String,dynamic>.from(r.data as Map));}on DioException catch(e){return ApiFailure(e.message??'Incident service unavailable',statusCode:e.response?.statusCode);}catch(e){return ApiFailure(e.toString());}}
}
