import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../shared/widgets/page_scaffold.dart';
import '../../../../shared/widgets/vuka_components.dart';
import '../../../../shared/widgets/safety_google_map.dart';
class IncidentMapScreen extends StatelessWidget { const IncidentMapScreen({super.key}); @override Widget build(BuildContext context)=>VukaPageScaffold(title:'Incident intelligence map',showSos:true,child:ListView(padding:const EdgeInsets.all(18),children:[const SafetyGoogleMap(height:360),const VukaCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Confidence labels',style:TextStyle(fontWeight:FontWeight.w800)),SizedBox(height:10),Wrap(spacing:8,runSpacing:8,children:[RiskChip('Low'),RiskChip('Higher'),RiskChip('High'),RiskChip('Verified')]),SizedBox(height:12),Text('Low-confidence reports are retained for aggregation but do not generate user alerts. Incident views describe places and events, never identifiable people.',style:TextStyle(color:Colors.white70,height:1.5))])),PrimaryAction('Report an incident',onPressed:()=>context.push('/report-incident'))])); }
