import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../shared/widgets/page_scaffold.dart';
import '../../../../shared/widgets/vuka_components.dart';

class TripSafetyProfileScreen extends StatelessWidget {
  const TripSafetyProfileScreen({super.key});

  @override
  Widget build(BuildContext context) => FeaturePage(
        title: 'Trip Safety Profile',
        description:
            'Review pickup, route and destination risk, the reasons behind each rating, data freshness and safer-route guidance.',
        showSos: true,
        sections: const [
          VukaCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Eyebrow('Safety overview'),
                SizedBox(height: 10),
                InfoRow(
                  'Pickup risk',
                  'Elevated',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Route risk',
                  'High',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Destination risk',
                  'Moderate',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Overall assessment',
                  'Insufficient data until server assessment',
                  trailing: SizedBox.shrink(),
                ),
              ],
            ),
          ),
        ],
        actions: [
          PrimaryAction(
            'Verify driver and vehicle',
            onPressed: () => context.push('/verify-driver'),
          ),
          PrimaryAction(
            'Start monitoring',
            onPressed: () => context.push('/active-trip'),
          ),
        ],
      );
}