import 'package:flutter/material.dart';
import '../../../../shared/widgets/validated_form_page.dart';

class CreateTripScreen extends StatelessWidget {
  const CreateTripScreen({super.key});

  @override
  Widget build(BuildContext context) => const ValidatedFormPage(
        title: 'Create a safety trip',
        description:
            'Enter pickup and destination to request a safety assessment. VUKA does not book rides, calculate fares or dispatch transport.',
        fields: [
          ('Pickup location', TextInputType.streetAddress),
          ('Destination', TextInputType.streetAddress),
        ],
        submitLabel: 'Assess trip safety',
        nextRoute: '/trip-safety',
      );
}