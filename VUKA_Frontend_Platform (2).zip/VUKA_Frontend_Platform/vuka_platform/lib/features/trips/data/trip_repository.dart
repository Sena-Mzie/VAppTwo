import 'package:dio/dio.dart';
import '../../../core/errors/api_result.dart';
abstract interface class TripRepository { Future<ApiResult<Map<String,dynamic>>> assess(String pickup,String destination); Future<ApiResult<Map<String,dynamic>>> startMonitoring(String tripId); Future<ApiResult<Map<String,dynamic>>> getTrip(String tripId); }
class RemoteTripRepository implements TripRepository { RemoteTripRepository(this._dio); final Dio _dio;
 @override Future<ApiResult<Map<String,dynamic>>> assess(String pickup,String destination)=>_request(()=>_dio.post('/trips/safety-assessment',data:{'pickup':pickup,'destination':destination}));
 @override Future<ApiResult<Map<String,dynamic>>> startMonitoring(String id)=>_request(()=>_dio.post('/trips/$id/monitoring/start'));
 @override Future<ApiResult<Map<String,dynamic>>> getTrip(String id)=>_request(()=>_dio.get('/trips/$id'));
 Future<ApiResult<Map<String,dynamic>>> _request(Future<Response<dynamic>> Function() call) async {try{final r=await call();return ApiSuccess(Map<String,dynamic>.from(r.data as Map));}on DioException catch(e){return ApiFailure(e.message??'Trip service unavailable',statusCode:e.response?.statusCode);}catch(e){return ApiFailure(e.toString());}}
}
