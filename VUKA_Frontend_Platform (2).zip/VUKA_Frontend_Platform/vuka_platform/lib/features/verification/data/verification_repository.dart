import 'package:dio/dio.dart';
import '../../../core/errors/api_result.dart';
abstract interface class VerificationRepository { Future<ApiResult<Map<String,dynamic>>> getRotatingQr(); Future<ApiResult<Map<String,dynamic>>> verifyQr(String token); }
class RemoteVerificationRepository implements VerificationRepository { RemoteVerificationRepository(this._dio); final Dio _dio;
 @override Future<ApiResult<Map<String,dynamic>>> getRotatingQr()=>_request(()=>_dio.post('/verification/driver/qr'));
 @override Future<ApiResult<Map<String,dynamic>>> verifyQr(String token)=>_request(()=>_dio.post('/verification/qr/verify',data:{'token':token}));
 Future<ApiResult<Map<String,dynamic>>> _request(Future<Response<dynamic>> Function() call) async {try{final r=await call();return ApiSuccess(Map<String,dynamic>.from(r.data as Map));}on DioException catch(e){return ApiFailure(e.message??'Verification service unavailable',statusCode:e.response?.statusCode);}catch(e){return ApiFailure(e.toString());}}
}
