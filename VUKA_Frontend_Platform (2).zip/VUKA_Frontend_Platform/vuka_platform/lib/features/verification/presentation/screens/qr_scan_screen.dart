import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/theme/colors.dart';

class QrScanScreen extends StatefulWidget {
  const QrScanScreen({super.key});

  @override
  State<QrScanScreen> createState() => _QrScanScreenState();
}

class _QrScanScreenState extends State<QrScanScreen> {
  bool handled = false;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Scan driver QR')),
        body: Column(
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Scan the rotating VUKA credential shown on the driver’s device. The scanned token must be verified by the server.',
              ),
            ),
            Expanded(
              child: MobileScanner(
                onDetect: (capture) {
                  if (handled) return;
                  final code = capture.barcodes.isEmpty
                      ? null
                      : capture.barcodes.first.rawValue;
                  if (code == null) return;
                  handled = true;
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'QR captured. Server verification is required.',
                      ),
                    ),
                  );
                  context.push('/verify-driver');
                },
                errorBuilder: (context, error, child) => Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(
                      'Camera unavailable: ${error.errorCode.name}. Check camera permission.',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: VukaColors.muted),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      );
}