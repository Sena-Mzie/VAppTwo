import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../../../../core/services/repository_providers.dart';
import '../../../../core/errors/api_result.dart';
import '../../../../core/theme/colors.dart';
import '../../../../shared/widgets/vuka_components.dart';

final driverQrProvider =
    FutureProvider.autoDispose<ApiResult>(
  (ref) => ref.read(verificationRepositoryProvider).getRotatingQr(),
);

class DriverQrScreen extends ConsumerWidget {
  const DriverQrScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final result = ref.watch(driverQrProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Your verification QR')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            'Show this rotating credential to a passenger before the trip. The QR token is issued and validated by the VUKA server.',
            style: TextStyle(color: VukaColors.muted, height: 1.5),
          ),
          const SizedBox(height: 20),
          Center(
            child: result.when(
              loading: () => const CircularProgressIndicator(),
              error: (e, _) => Text('Unable to load QR: $e'),
              data: (r) => r.fold<Widget>(
                success: (data) {
                  final token = data['token'] as String?;
                  if (token == null || token.isEmpty) {
                    return const Text('No valid QR credential was returned.');
                  }
                  return Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: QrImageView(data: token, size: 230),
                  );
                },
                failure: (message, code) => Column(
                  children: [
                    const Icon(
                      Icons.qr_code_2,
                      color: VukaColors.muted,
                      size: 60,
                    ),
                    const SizedBox(height: 8),
                    Text(message, textAlign: TextAlign.center),
                    if (code != null)
                      Text(
                        'HTTP $code',
                        style: const TextStyle(color: VukaColors.muted),
                      ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),
          const VukaCard(
            child: Text(
              'Credential rotation: every 60 seconds. A screenshot or expired credential must not pass verification.',
              style: TextStyle(color: VukaColors.muted),
            ),
          ),
          const SizedBox(height: 12),
          PrimaryAction(
            'Refresh credential',
            icon: Icons.refresh,
            onPressed: () => ref.invalidate(driverQrProvider),
          ),
        ],
      ),
    );
  }
}