import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../../../core/theme/colors.dart';

class DriverVerificationUploadScreen extends StatefulWidget {
  const DriverVerificationUploadScreen({super.key});

  @override
  State<DriverVerificationUploadScreen> createState() =>
      _DriverVerificationUploadScreenState();
}

class _DriverVerificationUploadScreenState
    extends State<DriverVerificationUploadScreen> {
  final _picker = ImagePicker();
  final Map<String, XFile?> _files = {};
  bool _submitting = false;
  final _labels = const [
    'South African ID',
    'Driver licence',
    'PrDP',
    'Vehicle registration',
    'Vehicle photo',
  ];

  Future<void> _pick(String label) async {
    final file = await _picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 85,
    );
    if (file != null) {
      setState(() => _files[label] = file);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Driver document verification')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text(
              'Upload clear images for secure review. Documents are private and are not included in community incident reports.',
              style: TextStyle(color: VukaColors.muted, height: 1.5),
            ),
            const SizedBox(height: 16),
            for (final label in _labels)
              Card(
                child: ListTile(
                  title: Text(label),
                  subtitle: Text(_files[label]?.name ?? 'No file selected'),
                  leading: const Icon(
                    Icons.description_outlined,
                    color: VukaColors.amber,
                  ),
                  trailing: IconButton(
                    tooltip: 'Choose image',
                    onPressed: () => _pick(label),
                    icon: const Icon(Icons.upload_file),
                  ),
                ),
              ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: _submitting
                  ? null
                  : () {
                      setState(() => _submitting = true);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            '${_files.length} of ${_labels.length} documents selected. Connect secure upload API to submit.',
                          ),
                        ),
                      );
                      setState(() => _submitting = false);
                    },
              child: Text(_submitting ? 'Submitting…' : 'Submit for review'),
            ),
          ],
        ),
      );
}