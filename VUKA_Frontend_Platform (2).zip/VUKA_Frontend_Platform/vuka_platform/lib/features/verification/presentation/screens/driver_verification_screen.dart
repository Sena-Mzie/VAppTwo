import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../shared/widgets/page_scaffold.dart';
import '../../../../shared/widgets/vuka_components.dart';

class DriverVerificationScreen extends StatelessWidget {
  const DriverVerificationScreen({super.key});

  @override
  Widget build(BuildContext context) => FeaturePage(
        title: 'Verify driver & vehicle',
        description:
            'Scan the rotating VUKA QR code shown on the driver’s device. Confirm that the driver, vehicle and registration match before entering.',
        showSos: true,
        sections: const [
          VukaCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Eyebrow('Safety overview'),
                SizedBox(height: 10),
                InfoRow(
                  'Driver identity',
                  'QR verification',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Vehicle registration',
                  'Compare with vehicle',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Verification result',
                  'Match / mismatch',
                  trailing: SizedBox.shrink(),
                ),
              ],
            ),
          ),
        ],
        actions: [
          PrimaryAction(
            'Scan driver QR',
            onPressed: () => context.push('/qr-scan'),
          ),
          PrimaryAction(
            'Report mismatch',
            onPressed: () => context.push('/report-incident'),
          ),
        ],
      );
}