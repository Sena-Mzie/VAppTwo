import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../shared/widgets/page_scaffold.dart';
import '../../../../shared/widgets/vuka_components.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) => FeaturePage(
        title: 'Your profile',
        description:
            'Manage personal details, account security, privacy and notifications.',
        showSos: true,
        sections: const [
          VukaCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Eyebrow('Safety overview'),
                SizedBox(height: 10),
                InfoRow(
                  'Personal information',
                  'View and update',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Security',
                  'PIN and biometrics',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Notifications',
                  'Manage preferences',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Privacy',
                  'Consent and data controls',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'App version',
                  '1.0.0',
                  trailing: SizedBox.shrink(),
                ),
              ],
            ),
          ),
        ],
        actions: [
          PrimaryAction(
            'Trusted contacts',
            onPressed: () => context.push('/trusted-contacts'),
          ),
          PrimaryAction(
            'Driver documents',
            onPressed: () => context.push('/driver-verification-upload'),
          ),
          PrimaryAction(
            'Log out',
            onPressed: () => context.push('/welcome'),
          ),
        ],
      );
}