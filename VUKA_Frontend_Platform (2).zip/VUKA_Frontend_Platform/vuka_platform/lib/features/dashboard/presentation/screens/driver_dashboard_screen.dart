import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../shared/widgets/page_scaffold.dart';
import '../../../../shared/widgets/vuka_components.dart';

class DriverDashboardScreen extends StatelessWidget {
  const DriverDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) => FeaturePage(
        title: 'Driver safety dashboard',
        description:
            'Review your verification status, vehicle details and incoming trip safety profile before you begin a journey.',
        showSos: true,
        sections: const [
          VukaCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Eyebrow('Safety overview'),
                SizedBox(height: 10),
                InfoRow(
                  'Verification status',
                  'Pending review',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Vehicle details',
                  'No verified vehicle loaded',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Today’s safety activity',
                  'No trips yet',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Risk intelligence',
                  'Available after trip assessment',
                  trailing: SizedBox.shrink(),
                ),
              ],
            ),
          ),
        ],
        actions: [
          PrimaryAction(
            'Upload verification documents',
            onPressed: () => context.push('/driver-verification-upload'),
          ),
          PrimaryAction(
            'View incoming trip',
            onPressed: () => context.push('/driver-incoming'),
          ),
          PrimaryAction(
            'Show my QR',
            onPressed: () => context.push('/driver-qr'),
          ),
          PrimaryAction(
            'Profile',
            onPressed: () => context.push('/profile'),
          ),
        ],
      );
}