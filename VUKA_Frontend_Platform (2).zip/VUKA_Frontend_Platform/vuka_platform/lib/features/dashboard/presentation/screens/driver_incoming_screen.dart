import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../shared/widgets/page_scaffold.dart';
import '../../../../shared/widgets/vuka_components.dart';

class DriverIncomingScreen extends StatelessWidget {
  const DriverIncomingScreen({super.key});

  @override
  Widget build(BuildContext context) => FeaturePage(
        title: 'Driver incoming trip',
        description:
            'Review the Trip Safety Profile before you decide how to proceed. This is not a ride-booking or dispatch marketplace.',
        showSos: true,
        sections: const [
          VukaCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Eyebrow('Safety overview'),
                SizedBox(height: 10),
                InfoRow(
                  'Pickup risk',
                  'High',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Route risk',
                  'Moderate',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Destination risk',
                  'Low',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Risk explanation',
                  '3 independent reports · confidence label required',
                  trailing: SizedBox.shrink(),
                ),
              ],
            ),
          ),
        ],
        actions: [
          PrimaryAction(
            'Review safety profile',
            onPressed: () => context.push('/trip-safety'),
          ),
          PrimaryAction(
            'Start safety monitoring',
            onPressed: () => context.push('/active-trip'),
          ),
          PrimaryAction(
            'Report an incident',
            onPressed: () => context.push('/report-incident'),
          ),
        ],
      );
}