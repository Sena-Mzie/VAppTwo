import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../shared/widgets/page_scaffold.dart';
import '../../../../shared/widgets/vuka_components.dart';

class HomeDashboardScreen extends StatelessWidget {
  const HomeDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) => FeaturePage(
        title: 'Your safety dashboard',
        description:
            'Your safety companion for the journey ahead. Risk assessments are server-calculated and show insufficient data when evidence is not adequate.',
        showSos: true,
        sections: const [
          VukaCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Eyebrow('Safety overview'),
                SizedBox(height: 10),
                InfoRow(
                  'Current area risk',
                  'Insufficient data',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Recent incidents',
                  'Confidence-labelled local signals',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Active trip',
                  'No active trip',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Safety summary',
                  'Your safety status at a glance',
                  trailing: SizedBox.shrink(),
                ),
              ],
            ),
          ),
        ],
        actions: [
          PrimaryAction(
            'Create a safety trip',
            onPressed: () => context.push('/create-trip'),
          ),
          PrimaryAction(
            'Trusted contacts',
            onPressed: () => context.push('/trusted-contacts'),
          ),
          PrimaryAction(
            'Incident intelligence map',
            onPressed: () => context.push('/incident-map'),
          ),
          PrimaryAction(
            'Report an incident',
            onPressed: () => context.push('/report-incident'),
          ),
          PrimaryAction(
            'Profile and settings',
            onPressed: () => context.push('/profile'),
          ),
        ],
      );
}