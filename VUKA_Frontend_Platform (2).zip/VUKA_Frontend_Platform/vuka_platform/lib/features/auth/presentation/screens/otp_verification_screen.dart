import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class OtpVerificationScreen extends StatefulWidget {
  const OtpVerificationScreen({super.key});

  @override
  State<OtpVerificationScreen> createState() => _OtpVerificationScreenState();
}

class _OtpVerificationScreenState extends State<OtpVerificationScreen> {
  final _form = GlobalKey<FormState>();
  final _otp = TextEditingController();

  @override
  void dispose() {
    _otp.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Verify your number'),
        ),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text(
              'Enter the 6-digit one-time PIN sent to your mobile number.',
            ),
            const SizedBox(height: 20),
            Form(
              key: _form,
              child: TextFormField(
                controller: _otp,
                maxLength: 6,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'One-time PIN',
                ),
                validator: (v) =>
                    (v ?? '').length != 6 ? 'Enter all 6 digits' : null,
              ),
            ),
            const SizedBox(height: 18),
            FilledButton(
              onPressed: () {
                if (_form.currentState!.validate()) {
                  context.push('/create-pin');
                }
              },
              child: const Text('Verify OTP'),
            ),
          ],
        ),
      );
}