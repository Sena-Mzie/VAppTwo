import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/services/service_providers.dart';
// import '../../../../shared/widgets/validated_form_page.dart';

class LoginScreen extends ConsumerWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) => Scaffold(
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              const Text(
                'Login',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Sign in using your registered phone number and secure PIN.',
                style: TextStyle(color: Colors.white70),
              ),
              const SizedBox(height: 20),
              const _LoginFields(),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () async {
                  final ok = await ref
                      .read(biometricServiceProvider)
                      .authenticate();
                  if (ok && context.mounted) {
                    context.go('/home');
                  }
                },
                icon: const Icon(Icons.fingerprint),
                label: const Text('Use biometrics'),
              ),
            ],
          ),
        ),
      );
}

class _LoginFields extends StatefulWidget {
  const _LoginFields();

  @override
  State<_LoginFields> createState() => _LoginFieldsState();
}

class _LoginFieldsState extends State<_LoginFields> {
  final _key = GlobalKey<FormState>();
  final _phone = TextEditingController();
  final _pin = TextEditingController();

  @override
  void dispose() {
    _phone.dispose();
    _pin.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Form(
        key: _key,
        child: Column(
          children: [
            TextFormField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'Mobile number'),
              validator: (v) => (v ?? '')
                          .replaceAll(RegExp(r'\D'), '')
                          .length <
                      9
                  ? 'Enter a valid phone number'
                  : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _pin,
              obscureText: true,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'PIN'),
              validator: (v) =>
                  (v ?? '').length < 4 ? 'Enter your PIN' : null,
            ),
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () {
                  if (_key.currentState!.validate()) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Connect the authentication API to complete sign-in.',
                        ),
                      ),
                    );
                  }
                },
                child: const Text('Continue'),
              ),
            ),
          ],
        ),
      );
}