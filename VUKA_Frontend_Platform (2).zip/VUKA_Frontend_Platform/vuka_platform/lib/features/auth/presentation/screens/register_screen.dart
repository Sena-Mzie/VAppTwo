import 'package:flutter/material.dart';
import '../../../../shared/widgets/validated_form_page.dart';

class RegisterScreen extends StatelessWidget {
  const RegisterScreen({super.key});

  @override
  Widget build(BuildContext context) => const ValidatedFormPage(
        title: 'Create your account',
        description:
            'Register as a passenger or driver. Driver identity and vehicle documents are handled in the secure verification workflow.',
        fields: [
          ('Full name', TextInputType.name),
          ('Mobile number', TextInputType.phone),
          ('Email address', TextInputType.emailAddress),
          ('User type (Passenger or Driver)', TextInputType.text),
        ],
        submitLabel: 'Continue',
        nextRoute: '/otp',
      );
}