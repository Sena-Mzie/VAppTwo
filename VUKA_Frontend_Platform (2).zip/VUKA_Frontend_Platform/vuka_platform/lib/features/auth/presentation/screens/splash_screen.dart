import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../shared/widgets/page_scaffold.dart';
import '../../../../shared/widgets/vuka_components.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) => FeaturePage(
        title: 'VUKA',
        description:
            'Checking your secure session and preparing your safety workspace.',
        showSos: true,
        sections: const [
          VukaCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Eyebrow('Safety overview'),
                SizedBox(height: 10),
                InfoRow(
                  'Session status',
                  'Secure storage',
                  trailing: SizedBox.shrink(),
                ),
                InfoRow(
                  'Connectivity',
                  'Checking network',
                  trailing: SizedBox.shrink(),
                ),
              ],
            ),
          ),
        ],
        actions: [
          PrimaryAction(
            'Continue to welcome',
            onPressed: () => context.push('/welcome'),
          ),
        ],
      );
}