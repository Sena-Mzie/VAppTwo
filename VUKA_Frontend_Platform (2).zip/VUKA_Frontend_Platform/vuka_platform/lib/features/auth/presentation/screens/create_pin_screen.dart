import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class CreatePinScreen extends StatefulWidget {
  const CreatePinScreen({super.key});

  @override
  State<CreatePinScreen> createState() => _CreatePinScreenState();
}

class _CreatePinScreenState extends State<CreatePinScreen> {
  final _form = GlobalKey<FormState>();
  final _pin = TextEditingController();
  final _confirm = TextEditingController();

  @override
  void dispose() {
    _pin.dispose();
    _confirm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Create security PIN'),
        ),
        body: Form(
          key: _form,
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              const Text(
                'Create a private PIN to protect your VUKA account.',
              ),
              const SizedBox(height: 18),
              TextFormField(
                controller: _pin,
                obscureText: true,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'PIN'),
                validator: (v) =>
                    (v ?? '').length < 6 ? 'Use at least 6 digits' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _confirm,
                obscureText: true,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Confirm PIN'),
                validator: (v) =>
                    v != _pin.text ? 'PINs do not match' : null,
              ),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: () {
                  if (_form.currentState!.validate()) {
                    context.go('/home');
                  }
                },
                child: const Text('Save PIN'),
              ),
            ],
          ),
        ),
      );
}