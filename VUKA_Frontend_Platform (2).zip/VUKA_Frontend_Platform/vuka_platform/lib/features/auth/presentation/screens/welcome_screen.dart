import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/theme/colors.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});
  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  bool passenger = true;
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 480),
          child: ListView(
            padding: const EdgeInsets.all(26),
            children: [
              const SizedBox(height: 36),
              const Center(child: Text('VUKA', style: TextStyle(color: VukaColors.amber, fontSize: 42, letterSpacing: 4, fontWeight: FontWeight.w900))),
              const SizedBox(height: 8),
              const Text('See the risk. Know the journey. Get home.', textAlign: TextAlign.center, style: TextStyle(color: VukaColors.muted)),
              const SizedBox(height: 52),
              const Text('I AM A', style: TextStyle(color: VukaColors.muted, fontSize: 11, letterSpacing: 1.2)),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(color: VukaColors.surface, borderRadius: BorderRadius.circular(14)),
                child: Row(children: [
                  Expanded(child: _role('Passenger', passenger, () => setState(() => passenger = true))),
                  Expanded(child: _role('Driver', !passenger, () => setState(() => passenger = false))),
                ]),
              ),
              const SizedBox(height: 22),
              SizedBox(height: 52, child: FilledButton(onPressed: () => context.push('/register'), child: const Text('Create account'))),
              const SizedBox(height: 12),
              SizedBox(height: 48, child: OutlinedButton(onPressed: () => context.push('/login'), child: const Text('Login'))),
              const SizedBox(height: 20),
              const Text('VUKA is a safety intelligence service, not a ride-booking or transport marketplace.', textAlign: TextAlign.center, style: TextStyle(color: VukaColors.muted, fontSize: 11, height: 1.5)),
            ],
          ),
        ),
      ),
    ),
  );

  Widget _role(String label, bool active, VoidCallback onTap) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(10),
    child: Container(
      height: 46,
      alignment: Alignment.center,
      decoration: BoxDecoration(color: active ? VukaColors.amber : Colors.transparent, borderRadius: BorderRadius.circular(10)),
      child: Text(label, style: TextStyle(color: active ? VukaColors.ink : VukaColors.text, fontWeight: FontWeight.w800)),
    ),
  );
}
