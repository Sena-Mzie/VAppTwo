import 'package:dio/dio.dart';
import '../../../core/errors/api_result.dart';
import '../../../shared/models/vuka_user.dart';
abstract interface class AuthRepository { Future<ApiResult<VukaUser>> requestOtp(String phone, UserRole role); Future<ApiResult<VukaUser>> verifyOtp(String phone, String otp); Future<ApiResult<void>> logout(); }
class RemoteAuthRepository implements AuthRepository {
  RemoteAuthRepository(this._dio); final Dio _dio;
  @override Future<ApiResult<VukaUser>> requestOtp(String phone, UserRole role) async { try { final r = await _dio.post('/auth/otp', data: {'phone': phone, 'role': role.name}); return ApiSuccess(VukaUser.fromJson(Map<String,dynamic>.from(r.data['user'] as Map))); } on DioException catch (e) { return ApiFailure(e.message ?? 'Unable to request OTP', statusCode: e.response?.statusCode); } catch (e) { return ApiFailure(e.toString()); } }
  @override Future<ApiResult<VukaUser>> verifyOtp(String phone, String otp) async { try { final r = await _dio.post('/auth/otp/verify', data: {'phone': phone, 'otp': otp}); return ApiSuccess(VukaUser.fromJson(Map<String,dynamic>.from(r.data['user'] as Map))); } on DioException catch (e) { return ApiFailure(e.message ?? 'OTP verification failed', statusCode: e.response?.statusCode); } catch (e) { return ApiFailure(e.toString()); } }
  @override Future<ApiResult<void>> logout() async { try { await _dio.post('/auth/logout'); return const ApiSuccess(null); } on DioException catch (e) { return ApiFailure(e.message ?? 'Logout failed', statusCode: e.response?.statusCode); } }
}
