import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../shared/widgets/page_scaffold.dart';
import '../../../../shared/widgets/vuka_components.dart';
import '../../../../shared/widgets/safety_google_map.dart';
class ActiveTripScreen extends StatelessWidget { const ActiveTripScreen({super.key}); @override Widget build(BuildContext context)=>VukaPageScaffold(title:'Live trip monitoring',showSos:true,child:ListView(padding:const EdgeInsets.all(18),children:[const SafetyGoogleMap(height:320),const VukaCard(child:Column(children:[InfoRow('Journey status','On expected route'),InfoRow('ETA','23:18'),InfoRow('Safety status','Monitoring'),InfoRow('Trusted contacts','2 shared') ])),const VukaCard(child:Text('Location and route updates are shown only when the user has granted the required permissions. A route deviation prompts a discreet safety check-in; it is not treated as proof of wrongdoing.')),PrimaryAction('Trip update / check-in',onPressed:()=>context.push('/safety-checkin')),const SizedBox(height:10),SecondaryAction('Report an incident',onPressed:()=>context.push('/report-incident'))])); }
