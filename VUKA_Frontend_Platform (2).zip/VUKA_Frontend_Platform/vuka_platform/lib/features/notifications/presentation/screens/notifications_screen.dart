import 'package:flutter/material.dart';
import '../../../../shared/widgets/page_scaffold.dart';
import '../../../../shared/widgets/vuka_components.dart';
class NotificationsScreen extends StatelessWidget { const NotificationsScreen({super.key}); @override Widget build(BuildContext context)=>const FeaturePage(title:'Notifications',description:'Safety alerts, check-in reminders and account updates. Notification delivery status is confirmed by the messaging service.',sections:[VukaCard(child:Column(children:[InfoRow('Safety alert','No new alerts'),InfoRow('Trip updates','No new updates'),InfoRow('Account notices','No new notices')]))]); }
