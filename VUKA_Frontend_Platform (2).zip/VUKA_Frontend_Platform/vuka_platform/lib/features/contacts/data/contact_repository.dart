import 'package:dio/dio.dart';
import '../../../core/errors/api_result.dart';
abstract interface class ContactRepository { Future<ApiResult<List<Map<String,dynamic>>>> list(); Future<ApiResult<Map<String,dynamic>>> invite(Map<String,dynamic> contact); Future<ApiResult<void>> remove(String id); }
class RemoteContactRepository implements ContactRepository { RemoteContactRepository(this._dio); final Dio _dio;
 @override Future<ApiResult<List<Map<String,dynamic>>>> list() async {try{final r=await _dio.get('/trusted-contacts');return ApiSuccess((r.data['items'] as List? ?? []).map((e)=>Map<String,dynamic>.from(e as Map)).toList());}on DioException catch(e){return ApiFailure(e.message??'Unable to load contacts',statusCode:e.response?.statusCode);}catch(e){return ApiFailure(e.toString());}}
 @override Future<ApiResult<Map<String,dynamic>>> invite(Map<String,dynamic> data) async {try{final r=await _dio.post('/trusted-contacts',data:data);return ApiSuccess(Map<String,dynamic>.from(r.data as Map));}on DioException catch(e){return ApiFailure(e.message??'Invitation failed',statusCode:e.response?.statusCode);}catch(e){return ApiFailure(e.toString());}}
 @override Future<ApiResult<void>> remove(String id) async {try{await _dio.delete('/trusted-contacts/$id');return const ApiSuccess<void>(null);}on DioException catch(e){return ApiFailure(e.message??'Unable to remove contact',statusCode:e.response?.statusCode);}catch(e){return ApiFailure(e.toString());}}
}
