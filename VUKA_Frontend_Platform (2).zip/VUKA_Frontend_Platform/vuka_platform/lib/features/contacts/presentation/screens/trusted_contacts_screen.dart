import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../shared/widgets/page_scaffold.dart';
import '../../../../shared/widgets/vuka_components.dart';

class TrustedContactsScreen extends StatelessWidget {
  const TrustedContactsScreen({super.key});
  @override
  Widget build(BuildContext context) => FeaturePage(
          title: 'Trusted contacts',
          description:
              'Manage people who may receive a time-limited trip-sharing link when you choose to share a journey.',
          showSos: true,
          sections: const [
            VukaCard(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                  Eyebrow('Safety overview'),
                  SizedBox(height: 10),
                  InfoRow('Mom · Family', 'Accepted',
                      trailing: SizedBox.shrink()),
                  InfoRow('Thando · Friend', 'Pending',
                      trailing: SizedBox.shrink()),
                  InfoRow('Contact permissions', 'Consent controlled',
                      trailing: SizedBox.shrink())
                ]))
          ],
          actions: [
            PrimaryAction('Add trusted contact',
                onPressed: () => context.push('/add-contact'))
          ]);
}
