import 'package:flutter/material.dart';
import '../../../../shared/widgets/validated_form_page.dart';

class AddContactScreen extends StatelessWidget {
  const AddContactScreen({super.key});

  @override
  Widget build(BuildContext context) => const ValidatedFormPage(
        title: 'Add trusted contact',
        description:
            'Invite someone you trust. They must accept before receiving a time-limited trip-sharing link.',
        fields: [
          ('Full name', TextInputType.name),
          ('Relationship', TextInputType.text),
          ('Phone number', TextInputType.phone),
        ],
        submitLabel: 'Send invitation',
        nextRoute: '/trusted-contacts',
      );
}